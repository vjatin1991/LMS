package EmployeePackage;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import LoginValidation.Valid;

@Controller

public class EmployeeController {

	@Autowired
	private Valid v;
	private EmployeeServices employeeServices;
	
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String loginPage(){
		return "login";
	}
	@RequestMapping(value="/",method=RequestMethod.POST)
	public String homePage(@RequestParam String empId,@RequestParam String empPassword,ModelMap model){
		
		if(!v.isvalid(empId,empPassword))
		{
			model.put("errorMessage","Invalid name or password");
			return "login";
			
		}
		model.put("empId", empId);
	
		return "homePage";
		
	}
	@RequestMapping("/add")
	public String addEmployee(){
		return "addEmployee";
	}
	
	@RequestMapping(value="/submitted", method=RequestMethod.POST)
	public String submitted(@ModelAttribute("employee") Employee employee){
		
		if (employeeServices.addEmployee(employee)){
			System.out.println("Congrats ! added");
		} else
			System.out.println("Unable to add");
		
		return "homePage";
	}
	
	@RequestMapping("/delete")
	public String deleteEmployee(){
		return "deleteEmployee";
	}
	
	@RequestMapping(value = "/deleting", method=RequestMethod.POST)
	public String deletedEmployee(@RequestParam("empId") String empId, Model model){
		
		Employee employee = employeeServices.deleteEmployee(empId);
		
		model.addAttribute("employee", employee);
		
		return "deleted";
		
	}
	@RequestMapping("/update")
	public String updateEmployee(){
		return "updateEmployee";
	}
}
