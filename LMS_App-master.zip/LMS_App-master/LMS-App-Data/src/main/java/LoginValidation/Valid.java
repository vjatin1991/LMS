package LoginValidation;

import org.springframework.stereotype.Component;

@Component
public class Valid {
	
	public boolean isvalid(String user,String pass)
	{
		if(user.equals("admin") && pass.equals("pass"))
			return true;
		 
		return false;
	}

}
