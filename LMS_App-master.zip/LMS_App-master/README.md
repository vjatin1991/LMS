# LMS_App
Our Leave management system
